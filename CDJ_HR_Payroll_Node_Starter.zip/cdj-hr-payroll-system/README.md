# CDJ Enterprize Ltd. HR & Payroll System
Private use only.